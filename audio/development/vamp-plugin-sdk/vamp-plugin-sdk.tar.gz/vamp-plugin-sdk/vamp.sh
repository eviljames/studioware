#!/bin/sh

export VAMP_PATH=/usr/lib@LIBDIRSUFFIX@/vamp

